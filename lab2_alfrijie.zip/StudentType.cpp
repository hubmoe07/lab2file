
#include "StudentType.h"
#include <iostream>
using namespace std;

void StudentType::Initialize(string newName, DateType newBirthdate, int newStatus) {
    status = newStatus;
    PersonType::Initialize(newName, newBirthdate);
}

int StudentType::GetStatus() const {
    return status;
}

RelationType StudentType::ComparedTo(StudentType& someStudent) {
    if (status < someStudent.GetStatus())
        return LESS;
    else if (status > someStudent.GetStatus())
        return GREATER;
    else
        return EQUAL;
}

DateType StudentType::BirthdateIs() {
    return PersonType::BirthdateIs();
}

void StudentType::Print() {
    PersonType::Print();
    cout << "Status: " << status << endl;
}
