
#ifndef STUDENTTYPE_H
#define STUDENTTYPE_H
#include "PersonType.h"

enum StudentStatus {NON_ATTENDING, ENROLLED, GRADUATED};

class StudentType : public PersonType {
public: 
  int GetStatus() const;
  void Initialize(string, DateType, int);
  RelationType ComparedTo(StudentType& someStudent);
  DateType BirthdateIs();
  void Print();
private:
  int status;
};

typedef StudentType ItemType;

#endif
